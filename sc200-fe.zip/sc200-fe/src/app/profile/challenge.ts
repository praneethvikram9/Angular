export class Challenge {
    challengeId: number;
    challengeName: string;
}
