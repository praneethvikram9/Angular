import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-nregistration',
  templateUrl: './login-nregistration.component.html',
  styleUrls: ['./login-nregistration.component.css']
})
export class LoginNRegistrationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
