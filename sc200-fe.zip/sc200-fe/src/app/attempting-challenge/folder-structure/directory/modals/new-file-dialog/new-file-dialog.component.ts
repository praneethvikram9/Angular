import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-file-dialog',
  templateUrl: './new-file-dialog.component.html',
  styleUrls: ['./new-file-dialog.component.css']
})
export class NewFileDialogComponent implements OnInit {

  file: string;
  constructor() { }

  ngOnInit() {
  }

}
