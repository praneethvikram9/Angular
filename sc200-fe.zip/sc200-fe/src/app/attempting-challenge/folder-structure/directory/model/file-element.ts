export class FileElement {
  id: string;
  isFolder: boolean;
  name: string;
  parent: string;
  url:string;
  content:string;
}

