export class File {
  url:string;
  content:string;
}

